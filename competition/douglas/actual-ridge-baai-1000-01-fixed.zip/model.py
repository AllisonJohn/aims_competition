"""Douglas BGE-ridge submission model.

This file is intentionally self-contained. The submitted ZIP only needs:

- model.py
- models.txt
- requirements.txt
- artifacts/bge_ridge_metadata_submit_a300_m1_artifact.json

The HuggingFace repo in models.txt is pre-downloaded by the evaluator. At
runtime we load it from the local cache only.
"""

from __future__ import annotations

import json
import math
import os
import re
from pathlib import Path

import torch


LOCAL_SMOKE_TEST_ENV = "PREDICTIVE_EVAL_LOCAL_SMOKE_TEST"
BGE_RIDGE_ARTIFACT_PATH = (
    Path(__file__).with_name("artifacts")
    / "bge_ridge_metadata_submit_artifact.json"
)
BGE_QUERY_PREFIX = "Represent this evaluation question for difficulty prediction: "
CLIP_LO = 1e-7
CLIP_HI = 1.0 - 1e-7

LEFT_MODEL_ID_KEYS = (
    "model_a_id",
    "model_id_a",
    "left_model_id",
    "subject_a_id",
    "subject_id_a",
)
RIGHT_MODEL_ID_KEYS = (
    "model_b_id",
    "model_id_b",
    "right_model_id",
    "subject_b_id",
    "subject_id_b",
)
LEFT_SUBJECT_CONTENT_KEYS = (
    "subject_a_content",
    "model_a_content",
    "left_subject_content",
    "subject_content_a",
)
RIGHT_SUBJECT_CONTENT_KEYS = (
    "subject_b_content",
    "model_b_content",
    "right_subject_content",
    "subject_content_b",
)


def _local_smoke_test_enabled() -> bool:
    value = os.environ.get(LOCAL_SMOKE_TEST_ENV, "")
    return value.strip().lower() in {"1", "true", "yes", "on"}


def _resolve_cache_dir() -> str | None:
    candidates = [
        os.environ.get("HF_HOME", "").strip(),
        "/app/hf_cache",
        str(Path(__file__).with_name(".hf_cache")),
    ]
    for candidate in candidates:
        if not candidate:
            continue
        path = Path(candidate)
        try:
            path.mkdir(parents=True, exist_ok=True)
        except OSError:
            continue
        if os.access(path, os.W_OK):
            return str(path)
    return None


def first_present(mapping: dict, keys: tuple[str, ...]):
    for key in keys:
        value = mapping.get(key)
        if value not in (None, ""):
            return value
    return None


def extract_model_metadata(subject_content: str | None, model_id: str | None = None) -> dict:
    metadata = {
        "model_id": model_id,
        "name": None,
        "organization": None,
        "size_params": None,
        "release_date": None,
        "family": None,
    }
    label_to_key = {
        "name": "name",
        "organization": "organization",
        "parameters": "size_params",
        "released": "release_date",
        "family": "family",
    }
    if not subject_content:
        return metadata
    for line in str(subject_content).splitlines():
        if ":" not in line:
            continue
        label, value = line.split(":", 1)
        key = label_to_key.get(label.strip().lower())
        if key:
            metadata[key] = value.strip() or None
    return metadata


def is_pairwise_input(input: dict) -> bool:
    has_left = (
        first_present(input, LEFT_MODEL_ID_KEYS) is not None
        or first_present(input, LEFT_SUBJECT_CONTENT_KEYS) is not None
    )
    has_right = (
        first_present(input, RIGHT_MODEL_ID_KEYS) is not None
        or first_present(input, RIGHT_SUBJECT_CONTENT_KEYS) is not None
    )
    return has_left and has_right


def extract_left_model_metadata(input: dict) -> dict:
    subject_content = first_present(input, LEFT_SUBJECT_CONTENT_KEYS)
    model_id = first_present(input, LEFT_MODEL_ID_KEYS)
    if subject_content is None and model_id is None:
        subject_content = input.get("subject_content")
        model_id = input.get("model_id")
    return extract_model_metadata(subject_content, model_id=model_id)


def extract_right_model_metadata(input: dict) -> dict:
    return extract_model_metadata(
        first_present(input, RIGHT_SUBJECT_CONTENT_KEYS),
        model_id=first_present(input, RIGHT_MODEL_ID_KEYS),
    )


def metadata_key(value) -> str:
    return str(value or "missing").strip().lower() or "missing"


def clip_probability(probability: float) -> float:
    return max(CLIP_LO, min(CLIP_HI, float(probability)))


def bge_item_numeric_features(text: str) -> list[float]:
    text = str(text or "")
    lower = text.lower()
    return [
        min(len(text), 5000) / 5000.0,
        min(len(text.split()), 1000) / 1000.0,
        min(text.count("\n"), 40) / 40.0,
        float(any(symbol in text for symbol in ("∫", "∑", "∂", "√", "≤", "≥", "∈"))),
        float(any(word in lower for word in ("prove", "derive", "justify", "counterexample"))),
        float(any(word in lower for word in ("def ", "class ", "import ", "function", "debug", "algorithm"))),
        float(any(word in lower for word in ("image", "figure", "diagram", "chart", "visual"))),
        float(any(word in lower for word in ("a)", "b)", "c)", "d)", "multiple choice", "choose the best"))),
    ]


def parse_params_billions(size_params: str | None, name: str | None) -> float | None:
    text = " ".join(value for value in (size_params, name) if value)
    if not text:
        return None
    mixture_match = re.search(r"(\d+(?:\.\d+)?)\s*x\s*(\d+(?:\.\d+)?)\s*([bBmM])", text)
    if mixture_match:
        count = float(mixture_match.group(1))
        size = float(mixture_match.group(2))
        unit = mixture_match.group(3).lower()
        value_b = count * size
        return value_b if unit == "b" else value_b / 1000.0
    values = []
    for number, unit in re.findall(r"(\d+(?:\.\d+)?)\s*([bBmM])", text):
        value = float(number)
        values.append(value if unit.lower() == "b" else value / 1000.0)
    return max(values) if values else None


def parse_release_year_month(release_date: str | None) -> tuple[float | None, float]:
    if not release_date:
        return None, 0.0
    match = re.search(r"(20\d{2}|19\d{2})(?:[-/](\d{1,2}))?", str(release_date))
    if not match:
        return None, 0.0
    year = float(match.group(1))
    month = float(match.group(2) or 1.0)
    return year, max(1.0, min(12.0, month))


def normalized_release_date(release_date: str | None) -> float:
    year, month = parse_release_year_month(release_date)
    if year is None:
        return 0.0
    decimal_year = year + (month - 1.0) / 12.0
    return max(0.0, min(1.0, (decimal_year - 2020.0) / 8.0))


def frontier_developer_feature(metadata: dict) -> float:
    text = " ".join(
        str(metadata.get(field) or "")
        for field in ("organization", "name", "model_id", "family")
    ).lower()
    markers = ("anthropic", "claude", "openai", "gpt", "google", "deepmind", "gemini")
    return float(any(marker in text for marker in markers))


def numeric_model_features(metadata: dict) -> list[float]:
    params_b = parse_params_billions(metadata.get("size_params"), metadata.get("name"))
    if params_b is None:
        log_params = 0.0
    else:
        log_params = max(0.0, min(1.0, math.log1p(params_b) / math.log1p(1000.0)))
    return [
        log_params,
        normalized_release_date(metadata.get("release_date")),
        frontier_developer_feature(metadata),
    ]


def bge_model_metadata_features(
    metadata: dict,
    group_mean_features: dict[str, dict[str, float]],
    global_theta: float,
) -> dict[str, float]:
    model_id = metadata_key(metadata.get("model_id"))
    name = metadata_key(metadata.get("name") or metadata.get("model_id"))
    params = metadata_key(metadata.get("size_params"))
    release = metadata_key(metadata.get("release_date"))
    return {
        "subject_group_mean": group_mean_features.get("subject_id", {}).get(model_id, global_theta),
        "name_group_mean": group_mean_features.get("display_name", {}).get(name, global_theta),
        "params_group_mean": group_mean_features.get("params", {}).get(params, global_theta),
        "release_group_mean": group_mean_features.get("release_date", {}).get(release, global_theta),
        "log_params": numeric_model_features(metadata)[0],
        "release_date": normalized_release_date(metadata.get("release_date")),
        "frontier_developer": frontier_developer_feature(metadata),
    }


class BGERidgeScorer:
    def __init__(self, artifact: dict, cache_dir: str | None = None) -> None:
        from transformers import AutoModel, AutoTokenizer

        self.encoder_id = artifact["encoder_id"]
        self.max_length = int(artifact.get("max_length", 256))
        self.benchmark_logit_offsets = {
            str(key): float(value)
            for key, value in artifact.get("benchmark_logit_offsets", {}).items()
        }
        self.benchmark_difficulty_priors = {
            str(key): float(value)
            for key, value in artifact.get("benchmark_difficulty_priors", {}).items()
        }

        item_ridge = artifact["item_ridge"]
        self.item_coef = torch.tensor(item_ridge["coef"], dtype=torch.float32)
        self.item_intercept = float(item_ridge["intercept"])
        self.item_feature_mean = torch.tensor(item_ridge["feature_mean"], dtype=torch.float32)
        self.item_feature_scale = torch.tensor(item_ridge["feature_scale"], dtype=torch.float32)

        self.model_lookup = artifact.get("model_lookup")
        self.model_ridge = artifact.get("model_ridge")
        if self.model_lookup is not None:
            self.global_theta = float(self.model_lookup.get("global_theta", 0.0))
            self.subject_theta_lookup = {
                str(key): float(value)
                for key, value in self.model_lookup.get("subject_theta_lookup", {}).items()
            }
            self.name_theta_lookup = {
                str(key): float(value)
                for key, value in self.model_lookup.get("name_theta_lookup", {}).items()
            }
        elif self.model_ridge is not None:
            self.model_coef = torch.tensor(self.model_ridge["coef"], dtype=torch.float32)
            self.model_intercept = float(self.model_ridge["intercept"])
            self.model_feature_names = list(self.model_ridge["feature_names"])
            self.model_feature_mean = torch.tensor(self.model_ridge["feature_mean"], dtype=torch.float32)
            self.model_feature_scale = torch.tensor(self.model_ridge["feature_scale"], dtype=torch.float32)
            self.global_theta = float(self.model_ridge.get("global_theta", 0.0))
            self.group_mean_features = {
                field: {str(key): float(value) for key, value in values.items()}
                for field, values in self.model_ridge.get("group_mean_features", {}).items()
            }
        else:
            raise ValueError("Artifact must contain either model_lookup or model_ridge.")

        self.tokenizer = AutoTokenizer.from_pretrained(
            self.encoder_id,
            cache_dir=cache_dir,
            local_files_only=True,
        )
        self.backbone = AutoModel.from_pretrained(
            self.encoder_id,
            cache_dir=cache_dir,
            local_files_only=True,
        )
        self.device = torch.device("cuda" if torch.cuda.is_available() else "cpu")
        self.backbone = self.backbone.to(self.device)
        self.backbone.eval()
        self.item_embedding_cache: dict[str, torch.Tensor] = {}

    def predict_probability(self, input: dict) -> float:
        with torch.no_grad():
            beta = self.predict_item_difficulty(input)
            if is_pairwise_input(input):
                theta_left = self.predict_theta(extract_left_model_metadata(input))
                theta_right = self.predict_theta(extract_right_model_metadata(input))
                logit = theta_left - theta_right - beta + self.benchmark_offset(input)
            else:
                theta = self.predict_theta(extract_left_model_metadata(input))
                logit = theta - beta + self.benchmark_offset(input)
            probability = torch.sigmoid(torch.tensor(float(logit), dtype=torch.float32))
        return clip_probability(float(probability))

    def predict_theta(self, metadata: dict) -> float:
        if self.model_lookup is not None:
            model_id = metadata_key(metadata.get("model_id"))
            name = metadata_key(metadata.get("name") or metadata.get("model_id"))
            return self.subject_theta_lookup.get(
                model_id,
                self.name_theta_lookup.get(name, self.global_theta),
            )

        feature_values = bge_model_metadata_features(
            metadata=metadata,
            group_mean_features=self.group_mean_features,
            global_theta=self.global_theta,
        )
        raw = torch.tensor(
            [feature_values.get(name, 0.0) for name in self.model_feature_names],
            dtype=torch.float32,
        )
        scaled = (raw - self.model_feature_mean) / self.model_feature_scale.clamp(min=1e-12)
        return float(torch.dot(scaled, self.model_coef) + self.model_intercept)

    def predict_item_difficulty(self, input: dict) -> float:
        benchmark = str(input.get("benchmark") or "")
        item_content = input.get("item_content") or ""
        embedding = self.cached_bge_embedding(item_content)
        numeric = torch.tensor(bge_item_numeric_features(item_content), dtype=torch.float32)
        raw = torch.cat([embedding, numeric])
        scaled = (raw - self.item_feature_mean) / self.item_feature_scale.clamp(min=1e-12)
        centered = float(torch.dot(scaled, self.item_coef) + self.item_intercept)
        return centered + self.benchmark_difficulty_priors.get(benchmark, 0.0)

    def benchmark_offset(self, input: dict) -> float:
        benchmark = str(input.get("benchmark") or "")
        return self.benchmark_logit_offsets.get(benchmark, 0.0)

    def cached_bge_embedding(self, text: str) -> torch.Tensor:
        if text not in self.item_embedding_cache:
            encoded = self.tokenizer(
                f"{BGE_QUERY_PREFIX}{text}",
                padding=True,
                truncation=True,
                max_length=self.max_length,
                return_tensors="pt",
            )
            encoded = {key: value.to(self.device) for key, value in encoded.items()}
            output = self.backbone(**encoded).last_hidden_state
            mask = encoded["attention_mask"].unsqueeze(-1).to(output.dtype)
            pooled = (output * mask).sum(dim=1) / mask.sum(dim=1).clamp(min=1)
            pooled = torch.nn.functional.normalize(pooled, p=2, dim=1)
            self.item_embedding_cache[text] = pooled.squeeze(0).detach().cpu()
        return self.item_embedding_cache[text]


def load_scorer(path: Path) -> BGERidgeScorer:
    artifact = json.loads(path.read_text(encoding="utf-8"))
    return BGERidgeScorer(artifact, cache_dir=_resolve_cache_dir())


SCORER = None
LOAD_ERROR = None

try:
    if _local_smoke_test_enabled():
        SCORER = None
    else:
        if not BGE_RIDGE_ARTIFACT_PATH.exists():
            raise FileNotFoundError(f"Missing model artifact: {BGE_RIDGE_ARTIFACT_PATH}")
        SCORER = load_scorer(BGE_RIDGE_ARTIFACT_PATH)
except Exception as exc:
    LOAD_ERROR = exc
    if _local_smoke_test_enabled():
        print(f"[douglas/model.py] WARNING: using fallback predictor ({exc!r})", flush=True)
    else:
        raise


def predict(input: dict, labeled: list[dict] | None = None) -> float:
    if SCORER is None:
        return 0.5
    return SCORER.predict_probability(input)
