"""BGE-large + centered IRT difficulty correction with blended Bayesian adapters.

Base predictor: smoothed subject/condition baseline.
Text correction: BGE-large embedding -> centered IRT item difficulty ridge model.
At prediction time, labeled examples update both a scalar logit shift and a
scalar IRT ability by MAP, then blend them with the base learned prediction.
"""

from __future__ import annotations

import json
import math
import re
from pathlib import Path


ROOT = Path(__file__).resolve().parent
with (ROOT / "artifacts" / "baseline_stats.json").open("r", encoding="utf-8") as f:
    STATS = json.load(f)
with (ROOT / "artifacts" / "bge_irt_ridge_artifact.json").open("r", encoding="utf-8") as f:
    ARTIFACT = json.load(f)

GLOBAL_RATE = float(STATS["global_rate"])
SUBJECT_RATES = STATS["subject_rates"]
CONDITION_RATES = STATS["condition_rates"]
BENCHMARK_RATES = STATS["benchmark_rates"]

SUBJECT_ALPHA = 250.0
CONDITION_ALPHA = 2000.0
BENCHMARK_ALPHA = 5000.0

MODEL_ID = ARTIFACT["encoder_id"]
BLEND_WEIGHT = float(ARTIFACT["blend_weight"])
PRIOR_WEIGHTS = ARTIFACT.get("prior_weights", {})
SUBJECT_WEIGHT = float(PRIOR_WEIGHTS.get("subject", 0.68))
CONDITION_WEIGHT = float(PRIOR_WEIGHTS.get("condition", 0.22))
BENCHMARK_WEIGHT = float(PRIOR_WEIGHTS.get("benchmark", 0.10))
ITEM_ADJUSTMENT_WEIGHT = float(PRIOR_WEIGHTS.get("item_adjustment", 1.0))
CALIBRATOR = ARTIFACT.get("calibrator")
RIDGE_INTERCEPT = float(ARTIFACT["ridge_intercept"])
RIDGE_COEF = [float(x) for x in ARTIFACT["ridge_coef"]]
SCALER_MEAN = [float(x) for x in ARTIFACT["scaler_mean"]]
SCALER_SCALE = [float(x) if float(x) != 0.0 else 1.0 for x in ARTIFACT["scaler_scale"]]
EMBEDDING_DIM = int(ARTIFACT["embedding_dim"])
MAX_LENGTH = int(ARTIFACT.get("max_length", 256))

TOKENIZER = None
ENCODER = None
TORCH = None
DEVICE = "cpu"
EMBED_CACHE: dict[str, list[float]] = {}


def _clamp(value: float, lo: float = 0.001, hi: float = 0.999) -> float:
    return max(lo, min(hi, float(value)))


def _logit(p: float) -> float:
    p = _clamp(p)
    return math.log(p / (1.0 - p))


def _sigmoid(x: float) -> float:
    return 1.0 / (1.0 + math.exp(-x))


def _smooth(rate_count: list[float] | None, alpha: float) -> float:
    if not rate_count:
        return GLOBAL_RATE
    rate, count = float(rate_count[0]), float(rate_count[1])
    return (rate * count + GLOBAL_RATE * alpha) / (count + alpha)


def _key(value: object) -> str:
    return str(value or "").strip().lower()


def _parse_subject_name(subject_content: object) -> str:
    text = str(subject_content or "")
    for line in text.splitlines():
        if ":" not in line:
            continue
        key, value = line.split(":", 1)
        if key.strip().lower() == "name":
            return value.strip().lower()
    return text.strip().splitlines()[0].lower() if text.strip() else ""


def _item_adjustment(item_content: object) -> float:
    text = str(item_content or "")
    lower = text.lower()
    length = len(text)
    adjustment = 0.0
    if length > 2500:
        adjustment -= 0.07
    elif length > 1000:
        adjustment -= 0.04
    elif 0 < length < 140:
        adjustment += 0.02
    if text.count("\n") > 12 or lower.count("part ") > 1:
        adjustment -= 0.03
    if any(symbol in text for symbol in ("∫", "∑", "∂", "√", "≤", "≥", "∈")):
        adjustment -= 0.04
    if re.search(r"\b(prove|derive|justify|rigorously|counterexample)\b", lower):
        adjustment -= 0.04
    if re.search(r"\b(def|class|import|function|bug|debug|runtime|algorithm)\b", lower):
        adjustment -= 0.03
    if re.search(r"\b(what is|who is|when did|where is)\b", lower) and length < 240:
        adjustment += 0.03
    if re.search(r"\b(a\)|b\)|c\)|d\)|multiple choice|choose the best)\b", lower):
        adjustment += 0.01
    return adjustment


def _base_prediction(input: dict) -> float:
    subject_name = _parse_subject_name(input.get("subject_content"))
    condition = _key(input.get("condition") or "none")
    benchmark = _key(input.get("benchmark"))
    subject_rate = _smooth(SUBJECT_RATES.get(subject_name), SUBJECT_ALPHA)
    condition_rate = _smooth(CONDITION_RATES.get(condition), CONDITION_ALPHA)
    benchmark_rate = _smooth(BENCHMARK_RATES.get(benchmark), BENCHMARK_ALPHA)
    z = (
        SUBJECT_WEIGHT * _logit(subject_rate)
        + CONDITION_WEIGHT * _logit(condition_rate)
        + BENCHMARK_WEIGHT * _logit(benchmark_rate)
        + ITEM_ADJUSTMENT_WEIGHT * _item_adjustment(input.get("item_content"))
    )
    return _clamp(_sigmoid(z))


def _numeric_features(item_content: object) -> list[float]:
    text = str(item_content or "")
    lower = text.lower()
    return [
        min(len(text), 5000) / 5000.0,
        min(len(text.split()), 1000) / 1000.0,
        min(text.count("\n"), 40) / 40.0,
        float(any(s in text for s in ("∫", "∑", "∂", "√", "≤", "≥", "∈"))),
        float(any(w in lower for w in ("prove", "derive", "justify", "counterexample"))),
        float(any(w in lower for w in ("def ", "class ", "import ", "function", "debug", "algorithm"))),
        float(any(w in lower for w in ("image", "figure", "diagram", "chart", "visual"))),
        float(any(w in lower for w in ("a)", "b)", "c)", "d)", "multiple choice", "choose the best"))),
    ]


def _ensure_encoder() -> bool:
    global TOKENIZER, ENCODER, TORCH, DEVICE
    if TOKENIZER is not None and ENCODER is not None:
        return True
    try:
        import torch
        from transformers import AutoModel, AutoTokenizer

        TORCH = torch
        DEVICE = "cuda" if torch.cuda.is_available() else "cpu"
        TOKENIZER = AutoTokenizer.from_pretrained(MODEL_ID, local_files_only=True)
        ENCODER = AutoModel.from_pretrained(MODEL_ID, local_files_only=True).to(DEVICE)
        ENCODER.eval()
        return True
    except Exception as exc:
        print(f"[submission8] Could not load encoder: {exc}", flush=True)
        TOKENIZER = None
        ENCODER = None
        return False


def _embed_item(item_content: object) -> list[float] | None:
    text = str(item_content or "")
    if text in EMBED_CACHE:
        return EMBED_CACHE[text]
    if not _ensure_encoder():
        return None
    prompt = f"Represent this evaluation question for difficulty prediction: {text}"
    try:
        with TORCH.no_grad():
            encoded = TOKENIZER(
                [prompt],
                padding=True,
                truncation=True,
                max_length=MAX_LENGTH,
                return_tensors="pt",
            )
            encoded = {key: value.to(DEVICE) for key, value in encoded.items()}
            output = ENCODER(**encoded).last_hidden_state
            mask = encoded["attention_mask"].unsqueeze(-1).to(output.dtype)
            pooled = (output * mask).sum(dim=1) / mask.sum(dim=1).clamp(min=1)
            pooled = TORCH.nn.functional.normalize(pooled, p=2, dim=1)
            vector = pooled[0].detach().cpu().tolist()
    except Exception as exc:
        print(f"[submission8] Embedding failed: {exc}", flush=True)
        return None
    EMBED_CACHE[text] = vector
    return vector


def _predict_centered_difficulty(item_content: object) -> float | None:
    embedding = _embed_item(item_content)
    if embedding is None or len(embedding) != EMBEDDING_DIM:
        return None
    numeric = _numeric_features(item_content)
    numeric = [
        (value - SCALER_MEAN[i]) / SCALER_SCALE[i]
        for i, value in enumerate(numeric)
    ]
    features = embedding + numeric
    return RIDGE_INTERCEPT + sum(coef * value for coef, value in zip(RIDGE_COEF, features))


def _calibrator_features(input: dict, difficulty: float) -> list[float]:
    subject_name = _parse_subject_name(input.get("subject_content"))
    condition = _key(input.get("condition") or "none")
    benchmark = _key(input.get("benchmark"))
    subject_rate = _smooth(SUBJECT_RATES.get(subject_name), SUBJECT_ALPHA)
    condition_rate = _smooth(CONDITION_RATES.get(condition), CONDITION_ALPHA)
    benchmark_rate = _smooth(BENCHMARK_RATES.get(benchmark), BENCHMARK_ALPHA)
    subject_logit = _logit(subject_rate)
    condition_logit = _logit(condition_rate)
    benchmark_logit = _logit(benchmark_rate)
    adjustment = _item_adjustment(input.get("item_content"))
    feature_values = {
        "subject_logit": subject_logit,
        "condition_logit": condition_logit,
        "benchmark_logit": benchmark_logit,
        "item_adjustment": adjustment,
        "difficulty": difficulty,
        "subject_x_difficulty": subject_logit * difficulty,
        "condition_x_difficulty": condition_logit * difficulty,
        "benchmark_x_difficulty": benchmark_logit * difficulty,
        "abs_difficulty": abs(difficulty),
    }
    names = CALIBRATOR.get("feature_names", []) if CALIBRATOR else []
    if names:
        return [feature_values[name] for name in names if name in feature_values]
    return [feature_values[name] for name in feature_values]


def _learned_skip_prediction(input: dict, difficulty: float) -> float | None:
    if not CALIBRATOR:
        return None
    features = _calibrator_features(input, difficulty)
    mean = [float(x) for x in CALIBRATOR["scaler_mean"]]
    scale = [float(x) if float(x) != 0.0 else 1.0 for x in CALIBRATOR["scaler_scale"]]
    coef = [float(x) for x in CALIBRATOR["coef"]]
    if not (len(features) == len(mean) == len(scale) == len(coef)):
        return None
    z = float(CALIBRATOR["intercept"])
    for value, mu, sigma, weight in zip(features, mean, scale, coef):
        z += weight * ((value - mu) / sigma)
    return _sigmoid(z)


SHIFT_ADAPT_L2 = 2.0
IRT_ADAPT_L2 = 1.5
BASE_BLEND = 0.50
SHIFT_BLEND = 0.25
IRT_BLEND = 0.25


def _uncalibrated_prediction(input: dict) -> float:
    base = _base_prediction(input)
    difficulty = _predict_centered_difficulty(input.get("item_content"))
    if difficulty is None:
        return base
    learned_prediction = _learned_skip_prediction(input, difficulty)
    if learned_prediction is None:
        return _sigmoid(_logit(base) - BLEND_WEIGHT * difficulty)
    return learned_prediction


def _subject_prior_logit(input: dict) -> float:
    subject_name = _parse_subject_name(input.get("subject_content"))
    subject_rate = _smooth(SUBJECT_RATES.get(subject_name), SUBJECT_ALPHA)
    return _logit(subject_rate)


def _label_from_example(example: dict) -> float | None:
    if "label" not in example:
        return None
    return _clamp(float(example["label"]), 0.0, 1.0)


def _shift_adapted_prediction(prediction: float, labeled: list[dict]) -> float | None:
    labeled_logits = []
    labels = []
    for example in labeled:
        label = _label_from_example(example)
        if label is None:
            continue
        labeled_logits.append(_logit(_uncalibrated_prediction(example)))
        labels.append(label)
    if not labels:
        return None
    delta = 0.0
    for _ in range(12):
        grad = SHIFT_ADAPT_L2 * delta
        hess = SHIFT_ADAPT_L2
        for base_logit, label in zip(labeled_logits, labels):
            q = _sigmoid(base_logit + delta)
            grad += q - label
            hess += q * (1.0 - q)
        if hess <= 1e-12:
            break
        delta -= grad / hess
    return _sigmoid(_logit(prediction) + delta)


def _irt_adapted_prediction(input: dict, labeled: list[dict]) -> float | None:
    target_difficulty = _predict_centered_difficulty(input.get("item_content"))
    if target_difficulty is None:
        return None
    labeled_difficulties = []
    labels = []
    for example in labeled:
        label = _label_from_example(example)
        if label is None:
            continue
        difficulty = _predict_centered_difficulty(example.get("item_content"))
        if difficulty is None:
            continue
        labeled_difficulties.append(float(difficulty))
        labels.append(label)
    if not labels:
        return None
    theta_prior = _subject_prior_logit(input)
    theta = theta_prior
    for _ in range(12):
        grad = IRT_ADAPT_L2 * (theta - theta_prior)
        hess = IRT_ADAPT_L2
        for difficulty, label in zip(labeled_difficulties, labels):
            q = _sigmoid(theta - difficulty)
            grad += q - label
            hess += q * (1.0 - q)
        if hess <= 1e-12:
            break
        theta -= grad / hess
    return _sigmoid(theta - float(target_difficulty))


def _calibrate_with_labeled(prediction: float, input: dict, labeled: list[dict] | None) -> float:
    if not labeled:
        return prediction
    shift_prediction = _shift_adapted_prediction(prediction, labeled)
    irt_prediction = _irt_adapted_prediction(input, labeled)
    weighted_sum = BASE_BLEND * prediction
    total_weight = BASE_BLEND
    if shift_prediction is not None:
        weighted_sum += SHIFT_BLEND * shift_prediction
        total_weight += SHIFT_BLEND
    if irt_prediction is not None:
        weighted_sum += IRT_BLEND * irt_prediction
        total_weight += IRT_BLEND
    if total_weight <= 0.0:
        return prediction
    return _clamp(weighted_sum / total_weight)


def predict(input: dict, labeled: list[dict] | None = None) -> float:
    base = _base_prediction(input)
    difficulty = _predict_centered_difficulty(input.get("item_content"))
    if difficulty is None:
        prediction = base
    else:
        learned_prediction = _learned_skip_prediction(input, difficulty)
        if learned_prediction is None:
            prediction = _sigmoid(_logit(base) - BLEND_WEIGHT * difficulty)
        else:
            prediction = learned_prediction
    prediction = _calibrate_with_labeled(prediction, input, labeled)
    return float(_clamp(prediction))
